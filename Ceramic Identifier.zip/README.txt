README.txt

CeramicIdentifier.exe
By Brandon Kindrick 2017
Version 0.9.0

//// Program Description ////

    This program takes in user input through combo boxes, and evaluates the the combination of answers. If the 
Combination of answers is a valid combination, it will output the number corresponding to that Ceramic Piece.


//// Installation ////

    When you download the CeramicPiece.zip File, extract the file to your desktop(or desired location). Right Click the file and select the "Extract files..." option. If this option is not available, please install either WinRAR or 7Zip. 

WinRAR: www.rarlab.com/download.htm
7Zip: www.7-zip.org/download.html

After being extracted, the "Ceramic Identifier.exe" icon can be double clicked to be run.


//// Known Issues/ Bugs ////

    Some Combinations will either give no output or give output when they should not. If you find a Combination which
should/ or should not exist, please contact Brandon Kindrick at bk423@nau.edu.